create trigger PRODUCT_INFORMATION_TR_SET_ID
    before insert
    on PRODUCT_INFORMATION
    for each row
begin
  if :new.PRODUCT_ID is null then
    select PRODUCTS_SEQ.nextval into :new.PRODUCT_ID
      from dual;
  end if;
end;
/

