create trigger WAREHOUSES_TR_SET_ID
    before insert
    on WAREHOUSES
    for each row
begin
  if :new.WAREHOUSE_ID is null then
    select WAREHOUSES_SEQ.nextval into :new.WAREHOUSE_ID
      from dual;
  end if;
end;
/

