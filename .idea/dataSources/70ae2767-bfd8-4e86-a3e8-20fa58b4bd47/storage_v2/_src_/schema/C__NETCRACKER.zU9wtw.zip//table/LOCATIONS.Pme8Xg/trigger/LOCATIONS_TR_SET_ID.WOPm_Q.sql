create trigger LOCATIONS_TR_SET_ID
    before insert
    on LOCATIONS
    for each row
begin
  if :new.LOCATION_ID is null then
    select LOCATIONS_SEQ.nextval into :new.LOCATION_ID
      from dual;
  end if;
end;
/

