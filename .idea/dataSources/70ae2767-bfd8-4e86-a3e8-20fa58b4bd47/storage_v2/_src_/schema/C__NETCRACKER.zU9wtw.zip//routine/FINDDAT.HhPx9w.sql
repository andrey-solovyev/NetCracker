create Function FindDat
   ( name_in IN varchar2 )
   RETURN number
IS
   cnumber number;
   CURSOR c1
   IS
     SELECT course_number
     FROM courses_tbl
     WHERE course_name = name_in;

BEGIN
   open c1;
   fetch c1 into cnumber;

   if c1%notfound then
      cnumber := 9999;
   end if;
   close c1;
RETURN cnumber;
select  case a
          when 'a' then
            'aa'
          when 'b' then
            'bb'
          else
            'xx'
        end
  from  dual
;
   /

