create trigger CUSTOMERS_TR_SET_ID
    before insert
    on CUSTOMERS
    for each row
begin
  if :new.CUSTOMER_ID is null then
    select CUSTOMERS_SEQ.nextval into :new.CUSTOMER_ID
      from dual;
  end if;
end;
/

