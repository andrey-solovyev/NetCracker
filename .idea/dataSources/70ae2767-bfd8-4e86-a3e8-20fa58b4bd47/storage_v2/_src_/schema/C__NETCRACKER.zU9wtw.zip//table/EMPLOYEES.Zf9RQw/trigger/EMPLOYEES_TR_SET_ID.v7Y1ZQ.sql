create trigger EMPLOYEES_TR_SET_ID
    before insert
    on EMPLOYEES
    for each row
begin
  if :new.EMPLOYEE_ID is null then
    select EMPLOYEES_SEQ.nextval into :new.EMPLOYEE_ID
      from dual;
  end if;
end;
/

