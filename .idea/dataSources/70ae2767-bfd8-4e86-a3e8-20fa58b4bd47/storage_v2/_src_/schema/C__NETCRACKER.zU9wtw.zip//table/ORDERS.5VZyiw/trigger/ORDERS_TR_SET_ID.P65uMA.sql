create trigger ORDERS_TR_SET_ID
    before insert
    on ORDERS
    for each row
begin
  if :new.ORDER_ID is null then
    select ORDERS_SEQ.nextval into :new.ORDER_ID
      from dual;
  end if;
end;
/

