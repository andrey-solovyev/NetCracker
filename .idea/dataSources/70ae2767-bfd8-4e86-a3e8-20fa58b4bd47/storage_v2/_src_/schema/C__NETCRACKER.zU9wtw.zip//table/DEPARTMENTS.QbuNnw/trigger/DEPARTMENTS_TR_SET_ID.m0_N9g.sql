create trigger DEPARTMENTS_TR_SET_ID
    before insert
    on DEPARTMENTS
    for each row
begin
  if :new.DEPARTMENT_ID is null then
    select DEPARTMENTS_SEQ.nextval into :new.DEPARTMENT_ID
      from dual;
  end if;
end;
/

