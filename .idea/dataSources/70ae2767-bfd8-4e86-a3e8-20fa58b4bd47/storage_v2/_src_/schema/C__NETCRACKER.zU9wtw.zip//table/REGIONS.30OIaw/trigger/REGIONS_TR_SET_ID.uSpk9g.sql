create trigger REGIONS_TR_SET_ID
    before insert
    on REGIONS
    for each row
begin
  if :new.REGION_ID is null then
    select REGIONS_SEQ.nextval into :new.REGION_ID
      from dual;
  end if;
end;
/

